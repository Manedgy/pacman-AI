package games.pacman.controllers;

/**
 * User: Simon
 * Date: 19-May-2008
 * Time: 16:37:43
 */
public interface TDController extends PacController {
    public void update(double delta);
}
