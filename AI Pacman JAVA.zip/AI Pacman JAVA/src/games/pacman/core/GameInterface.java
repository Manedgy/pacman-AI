package games.pacman.core;

/**
 * Created by IntelliJ IDEA.
 * User: sml
 * Date: 27-Sep-2004
 * Time: 14:25:10
 * To change this template use Options | File Templates.
 */
public interface GameInterface {
    public boolean gameOn();
    public int getScore();
    public int getHighScore();
}
