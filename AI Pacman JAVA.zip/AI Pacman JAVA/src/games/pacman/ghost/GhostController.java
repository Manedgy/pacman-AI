package games.pacman.ghost;

public interface GhostController {
    public int preferredMove();
}
