package games.pacman.view;

/**
 * Created by IntelliJ IDEA.
 * User: simon
 * Date: 10-Dec-2008
 * Time: 23:17:51
 * To change this template use File | Settings | File Templates.
 */
public class AimSpot extends Mobile {

    public AimSpot() {
        rad = 6;
    }
}
