package screenpac.grid;

/**
 * Created by IntelliJ IDEA.
 * User: sml
 * Date: 27-Mar-2010
 * Time: 15:32:19
 * To change this template use File | Settings | File Templates.
 */
public class EnumTest {
    enum mod {LEFT, RIGHT};

    public static void main(String[] args) {
        mod m = mod.LEFT;
    }
}
