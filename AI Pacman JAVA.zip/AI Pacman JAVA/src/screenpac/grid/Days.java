package screenpac.grid;

/**
 * Created by IntelliJ IDEA.
 * User: sml
 * Date: 27-Mar-2010
 * Time: 15:34:27
 * To change this template use File | Settings | File Templates.
 */
public enum Days {
    MONDAY, TUESDAY;
}
