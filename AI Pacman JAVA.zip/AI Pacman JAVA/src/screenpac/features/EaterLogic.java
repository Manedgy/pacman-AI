package screenpac.features;

import screenpac.model.Node;
import wox.serial.Util;
import screenpac.model.GameState;
import screenpac.model.GameStateInterface;
import screenpac.model.GhostState;
import screenpac.features.Utilities;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

import games.pacman.ghost.Ghost;

//import javax.swing.text.Utilities;

/**
 * This class is responsible for all the code logic, from the A* algorithm to auxiliar methods.
 * @author David Teixeira Nº67994
 * @author Pedro Santos Nº67984
 */
public class EaterLogic implements NodeScore {
    static int max = Integer.MAX_VALUE;

    public Node closest = null;
    
    /**
     * Check if a node is a ghost
     * @param gs GameState
     * @param n Node
     * @return Whether the node is a ghost or not
     */
    private boolean hasGhost(GameStateInterface gs, Node n)
    {
        for(GhostState g : gs.getGhosts())
            if(Utilities.manhattan(g.current, n) == 0) return true;
        
        return false;
    }


    /**
     * This method is part of the A* algorithm.
     * @param gs Game state
     * @param n Node
     * @return The distance from the Pacman's current position to the target node, representing the cost of the path.
     */
    private int getG(GameStateInterface gs, Node n)
    {
        // for(Node n : pathTillActual)
        //     if(hasGhost(gs, n)) return Utilities.manhattan(n, gs.getPacman().current);
        // GhostState[] ghosts = gs.getGhosts();
        // int result = 0;
        // for(int i = 0; i < ghosts.length; i++)
        //     if(Utilities.manhattan(ghosts[i].current, gs.getPacman().current) <= 10) result = 999999;
        // return result;
        return Utilities.manhattan(n, gs.getPacman().current);
    }

    /**
     * This method is part of the A* algorithm.
     * @param gs Game state
     * @param actual Actual node
     * @param target Target node
     * @return The distance from the actual node to the target node, representing the cost of the path.
     */
    private int getH(GameStateInterface gs, Node actual, Node target)
    {
        return Utilities.manhattan(actual, target);
    }

    /**
     * Returns the successor (aka adjacent) nodes of the actual node.
     * @param n Node
     * @return Array of adjacent nodes.
     */
    private ArrayList<Node> sucessores(Node n) {

		for(Node e : n.adj) {
			if(e.father == null) e.father = n;
		}
		return n.adj;
	}

    /**
     * Remove duplicates from a list of nodes.
     * @param gs Game state
     * @param arr Array of nodes
     * @return Array of nodes without duplicates
     */
    private ArrayList<Node> removeDup(GameStateInterface gs, ArrayList<Node> arr)
    {
        ArrayList<Node> noDup = new ArrayList<>();
        int n = arr.size();

        ArrayList<Integer> distances = new ArrayList<>();
        for(int i = 0; i < n; i++)
            distances.add(Utilities.manhattan(arr.get(i), gs.getPacman().current));

        ArrayList<Integer> noDupDist = new ArrayList<>();
        for(int i = 0; i < n; i++)
        {
            if(!noDupDist.contains(distances.get(i))) 
            {
                noDupDist.add(distances.get(i));
                noDup.add(arr.get(i));
            }
        }
        return noDup;
    }

    /**
     * Modifies the "closest" variable's value to the closest pill/power node, avoiding ghosts.
     * @param gs Game state
     * @param node Pacman node
     * @return Minimum distance from the pacman to the pills
     */
    public double score(GameStateInterface gs, Node node) {
        // most obvious way: iterate over the set of pills
        // int closest
        int minDist = max;
        Node pac = gs.getPacman().current;


        GhostState[] allGhosts = gs.getGhosts();
        //Get all ghost distances to pacman
        int[] ghostDistances = new int[allGhosts.length];
        int j = 0;
        for (GhostState ghost : allGhosts) {
        	// get the current ghost node
        	Node n = ghost.current;
        	ghostDistances[j] = Utilities.manhattan(n, gs.getPacman().current);
            j++;
        }

        //Get some of the closest nodes to pacman and put them on allNodes
        ArrayList<Node> allPillNodes = new ArrayList<>(); //= gs.getMaze().getPills();
        //for(Node n : gs.getMaze().getPills())

        //allNodes = removeDup(gs, allNodes);
        for (Node n : gs.getMaze().getPills()) {
            // check the state of this pill
            // by querying the BitSet of pill states
            if (gs.getPills().get(n.pillIndex)) {
                // this pill is on, but is it closer?
                if (gs.getMaze().dist(node, n) < minDist) {
                    minDist = gs.getMaze().dist(node, n);
                    closest = n;

                    //allNodes.add(n);
                }
                //allNodes.add(n);
            }
        }

        for (Node n : gs.getMaze().getPowers()) {
            // check the state of this pill
            // by querying the BitSet of pill states
            if (gs.getPowers().get(n.powerIndex)) {
                // this pill is on, but is it closer?
                if (gs.getMaze().dist(node, n) < minDist) {
                    minDist = gs.getMaze().dist(node, n);
                    closest = n;

                    //allNodes.add(n);
                }
                //allNodes.add(n);
            }
        }
        //sort(gs, allNodes);
        // System.out.println("ALL NODES: ");
        // for(Node n : allNodes)
        // {
        //     System.out.println(n + " BRUH: " + Utilities.manhattan(n, gs.getPacman().current) + " BRUH2: " + gs.getMaze().dist(n, gs.getPacman().current));
        // }
        // System.out.println("DONE");

        // int nodesAmount = allNodes.size(); // number of nearest pills (can be at least 4 or less)
        // int iterations = nodesAmount >= 4 ? 4 : nodesAmount;
        
        // int savedDistance = Integer.MAX_VALUE; //Minimum ghost distance to nearast pill
        // int[] furthestGhosts = new int[iterations]; //
        // Node[] nearPills = new Node[iterations];
        // //GhostState[] allGhosts = gs.getGhosts();
        // int[] ghostDistancesToPill = new int[gs.getGhosts().length];
        // System.out.println("START");
        // for(int i = 0; i < iterations; i++)
        // {
        //     nearPills[i] = allNodes.get(i); //Get the nearest 4 or less pills
        //     int distance = Utilities.manhattan(nearPills[i], gs.getPacman().current); //Calcute distance to pacman
        //     //int distance = gs.getMaze().dist(nearPills[i], gs.getPacman().current);

        //     //get all ghost distances to current pill (nearPill[i])
        //     for(int k = 0; k < ghostDistancesToPill.length; k++)
        //     {
        //         /*if(!allGhosts[k].edible())*/ ghostDistancesToPill[k] = Utilities.manhattan(allGhosts[k].current, nearPills[i]);
        //         //else ghostDistancesToPill[k] = 99999;
        //         //ghostDistancesToPill[k] =  gs.getMaze().dist(allGhosts[k].current, nearPills[i]);
        //     }

        //     for (int k = 0; k < 4; k++) { // for each ghost, calculate the distance between it and the pill
                
        //         // ghostDistance[k] = distance from ghost to pacman
        //         //int furthestDistance = distance + ghostDistances[k];

        //         // ghostDistance2[k] = distance from ghost to pill i
        //         int closestGhostToPill = distance + ghostDistancesToPill[k];

        //         //furthestDistance = furthestDistance <= 0 ? furthestDistance * -1 : furthestDistance;

        //         if (closestGhostToPill < savedDistance) savedDistance = closestGhostToPill;
        //     }

        //     furthestGhosts[i] = savedDistance;
        //     savedDistance = Integer.MAX_VALUE;
            
        //     System.out.println("PILLS: " + nearPills[i] + " DISTANCE: " + distance + " NEAREST GHOST " + (furthestGhosts[i] - distance));
        //     nearPills[i].col = Color.orange;
            
        // }
        // System.out.println("END");
        // int closestPillIndex = 0;

        // for (int i = 0; i < furthestGhosts.length; i++) {
        //     closestPillIndex = furthestGhosts[i] > furthestGhosts[closestPillIndex] ? i : closestPillIndex;
        // }

        // // System.out.println("START");
        // // for(int i = 0; i < nearPills.length; i++)
        // // {
        // //     System.out.println("PILLS: " + nearPills[i] + " NEAREST GHOST " + furthestGhosts[i]);
        // //     nearPills[i].col = Color.orange;
        // //    //System.out.println(n);
        // // }
        // // System.out.println("END");

        // System.out.println("BEST PILL: " + nearPills[closestPillIndex] + " NEAREST GHOST " + furthestGhosts[closestPillIndex] + " PAC: " + pac);
        // closest = nearPills[closestPillIndex];
        //closest.col = Color.ORANGE;
        //System.out.println(closest);

        

        //if (allGhosts[furthestPillIndex].current != null) { allGhosts[furthestPillIndex].current.col = Color.CYAN; }
        // System.out.println("BRUH3");
        // for(Node n : allNodes) {
        //     System.out.println(n.toString() + " DIST: " + Utilities.manhattan(n, gs.getPacman().current));
        // }
        // System.out.println("BRUH4");

        // sort(gs, allNodes);

        // System.out.println("BRUH");
        // for(Node n : allNodes) {
        //     System.out.println(n.toString() + " DIST: " + Utilities.manhattan(n, gs.getPacman().current));
        // }
        // System.out.println("BRUH2");

        if (closest != null) {
            closest.col = Color.magenta;
        }     
        return minDist;
    }

    /**
     * Sorts the list of nodes by distance to pacman
     * @param gs GameState
     * @param arr ArrayList of nodes
     */
    void sort(GameStateInterface gs, ArrayList<Node> arr)
    {
        int n = arr.size();
        for (int i = 1; i < n; ++i) {
            Node key = arr.get(i);
            int j = i - 1;
 
            /* Move elements of arr[0..i-1], that are
               greater than key, to one position ahead
               of their current position */
            //while (j >= 0 && Utilities.manhattan(arr.get(j), gs.getPacman().current) > Utilities.manhattan(key, gs.getPacman().current)) {
            while (j >= 0 && gs.getMaze().dist(arr.get(j), gs.getPacman().current) > gs.getMaze().dist(key, gs.getPacman().current)) {
                arr.set(j+1, arr.get(j));
                j = j - 1;
            }
            arr.set(j+1, key);
        }
    }

    //int[] ghostPlusPills = new int]
    // public double score(GameStateInterface gs, Node node) {
    //     // most obvious way: iterate over the set of pills
    //     // int closest
    //     int minDist = max;
    //     for (GhostState ghost : gs.getGhosts()) {
        	
    //     	// get the current ghost node
    //     	Node n = ghost.current;
        	
    //         // check is exists
    //         if (n != null) {
    //             // get distance
    //             if (gs.getMaze().dist(node, n) < minDist) {
    //                 minDist = gs.getMaze().dist(node, n);
    //                 closest = n;
    //             }
    //         }
    //     }
    //     if (closest != null) {
    //         closest.col = Color.blue;
    //     }
    //     return minDist;
    // }
    
    /**
     * Implementation of the A* algorithm
     * @param gs GameState
     * @return Solution path to the closest pill from the current Pacman position
     */
    public ArrayList<Node> aStar(GameStateInterface gs)
    {
        ArrayList<Node> pathTillActual = new ArrayList<Node>();
        Queue<Node> abertos = new PriorityQueue<>(10, (s1, s2) -> (int) Math.signum((getH(gs, (Node) s1, closest) + getG(gs, s2)) - (getH(gs, (Node) s2, closest) + getG(gs, s2))));
        
        ArrayList<Node> fechados = new ArrayList<>(), solutionPath = new ArrayList<>(), sucs = new ArrayList<>();
        

        Node actual = gs.getPacman().current;
        actual.father = actual;
        abertos.add(actual);

        //System.out.println("CLOSEST: " + closest);
        
        while(true)
        {
            //System.out.println("BRHH");
            if(abertos.isEmpty() || abertos.peek() == null) break;

            actual = abertos.poll();

            if(actual.x == closest.x && actual.y == closest.y)
            {
                //System.out.println("SAI: " + actual);
                //break;
                break;
            }
            else
            {
                sucs = sucessores(actual);

                // for(Node n : sucs)
                // {
                //     System.out.println("SUC: " + n + " SIZE: " + sucs.size());
                // }
                // System.out.println("END SUC");
                // for(Node suc : sucs)
                // {
                //     for(GhostState ghost : gs.getGhosts())
                //         {
                //             for(Node a : ghost.current.adj)
                //             {
                //                 if((suc.x == a.x && suc.y == a.y) || (suc.x == ghost.current.x && suc.y == ghost.current.y)) fechados.add(suc);
                //             }
                //         }
                // }

                fechados.add(actual);

                for(Node n : sucs)
                {
                    if(!fechados.contains(n) && !abertos.contains(n)) abertos.add(n);
                }
            }
        }
        //System.out.println("BRHH2 ");

        //Node pac = gs.getPacman().current;
        

        // System.out.println("ACTUAL: " + actual);
        // actual = actual.father;
        // System.out.println("ACTUAL2: " + actual);
        // actual = actual.father;
        // System.out.println("ACTUAL3: " + actual);
        // actual = actual.father;
        
        if(actual == actual.father) solutionPath.add(actual);
        while(actual != actual.father)
        {
            //System.out.println("BRHH3 " + actual + " PAC: " + pac);
            solutionPath.add(actual);
            actual = actual.father;
            //System.out.println("ACTUAL: " + actual);
        }
        //System.out.println("BRHH4");
        return solutionPath;
    }

    /**
     * (edible ghosts version)
     * Modifies the "closest" variable's value to the closest pill/power node, NOT avoiding the ghosts
     * @param gs Game state
     * @param node Pacman node
     * @return Minimum distance from the pacman to the pills
     */
    public double scoreEdible(GameStateInterface gs, Node node) {
        // most obvious way: iterate over the set of pills
        // int closest
        int minDist = max;
        for (GhostState ghost : gs.getGhosts()) {
        	
        	// get the current ghost node
        	Node n = ghost.current;
        	
            // check is exists
            if (n != null && ghost.edible()) {
                // get distance
                if (gs.getMaze().dist(node, n) < minDist) {
                    minDist = gs.getMaze().dist(node, n);
                    closest = n;
                }
            }
        }
        if (closest != null) {
            closest.col = Color.red;
        }
        return minDist;
    }
}
