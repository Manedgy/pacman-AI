package screenpac.features;

import screenpac.model.Node;
import screenpac.model.GameState;

public class InfluenceMap implements NodeFeatureExtractor {

    public double[] getFeatures(GameState gs, Node node) {
        return new double[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int nFeatures() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
