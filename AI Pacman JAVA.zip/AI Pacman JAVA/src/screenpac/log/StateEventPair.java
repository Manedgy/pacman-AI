package screenpac.log;

import screenpac.model.GameStateSetter;

public class StateEventPair {
    GameStateSetter gs;
    Event event;
}
