package screenpac.extract;

public class NodeDist {
    public ENode node;
    public int dist;

    public NodeDist(ENode node, int dist) {
        this.node = node;
        this.dist = dist;
    }
}
