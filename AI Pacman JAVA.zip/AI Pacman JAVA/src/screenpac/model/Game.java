package screenpac.model;

import java.util.ArrayList;

import javax.swing.text.Utilities;

import games.pacman.maze.MazeOne;
import screenpac.sound.PlaySound;
import utilities.JEasyFrame;
import utilities.ElapsedTimer;
import utilities.StatSummary;
import screenpac.extract.Constants;
import screenpac.controllers.AgentInterface;
import screenpac.controllers.Group1;
import screenpac.controllers.SimplePillEater;
import screenpac.controllers.SmartEater;
import screenpac.controllers.SmartPillEater;
import screenpac.controllers.RandomAgent;
import screenpac.controllers.RandomNonReverseAgent;
import screenpac.ghosts.GhostTeamController;
import screenpac.ghosts.RandTeam;
import screenpac.ghosts.PincerTeam;
import screenpac.ghosts.LegacyTeam;

/**
 * This class is responsible for all the game mechanics, bringing together the agent controllers.
 * Iy may also be responsible for taking actions that depend on the game state.
 */
public class Game implements Constants {
	//default is 40;
    static int delay = 1;
    static boolean visual = true;

    public static void main(String[] args) throws Exception {
        //AgentInterface agent = new SmartEater();
        AgentInterface agent = new Group1();
        //agent = new RandomAgent();
        GhostTeamController ghostTeam;
        // ghostTeam = new RandTeam();
        ghostTeam = new PincerTeam();
        // ghostTeam = new LegacyTeam();

        if (visual) runVisual(agent, ghostTeam);
        else runDark(agent, ghostTeam);
    }

    public static void runVisual(AgentInterface agentController, GhostTeamController ghostTeam) throws Exception {
        GameState gs = new GameState();
        gs.nextLevel();
        //gs.nextLevel();
        // gs.nextLevel();
        gs.nLivesRemaining = 10;
        // gs.reset();
        GameStateView gsv = new GameStateView(gs);
        PlaySound.enable();
        JEasyFrame fr = new JEasyFrame(gsv, "Pac-Man vs Ghosts", true);
        //KeyController kc = new KeyController();
        //fr.addKeyListener(kc);
        Game game = new Game(gs, gsv, agentController, ghostTeam);
        game.frame = fr;
        game.run();
        // use line below to run for a max number of cycles
        // game.run(100);
        System.out.println("Final score: " + game.gs.score);
    }

    public void run() throws Exception {
        // System.out.println("nLives left: " + gs.nLivesRemaining);
        while(!gs.terminal()) {
            cycle();
            // System.out.println(gs.pills.cardinality() + " : " + gs.powers.cardinality());
        }
        System.out.println("nLives left: " + gs.nLivesRemaining);
    }

    public void run(int n) throws Exception {
        int i=0;
        while(i++ < n && !gs.terminal()) {
            cycle();
        }
    }

    public static int getwd(Node a, Node b, Maze maze) {
        int w = maze.getWidth();
        int h = maze.getHeight();

        //System.out.println("A: " + a + " B: " + b);
        for (int i = 0; i < dx.length; i++) {
            if (
                    ((a.x + dx[i] + w) % w == b.x) &&
                    ((a.y + dy[i] +h) % h == b.y)
                    )
            {
                //System.out.println("BRUH: " + i);
                return i;
            }
        }
        // something's wrong
        System.out.println("Non-adjacent nodes in getWrappedDirection");
        return NEUTRAL;
    }

    public void cycle() throws Exception {
        // update the game state
        // ArrayList<Node> solutionPath = agentController.getSolutionPath(gs);

        // int n = solutionPath.size(), i = n-1;
        // System.out.println("PAC: " + gs.getPacman().current);
        // for(Node f : solutionPath)
        // {
        //     System.out.println("NODE: " + f);
        // }

        //while(i > 0)
        //{
           // gs.next(getwd(solutionPath.get(i), solutionPath.get(i-1), gs.getMaze()), ghostTeam.getActions(gs));
           gs.next(agentController.action(gs), ghostTeam.getActions(gs));
            if (gsv != null) {
                gsv.repaint();
                if (frame != null) frame.setTitle("Score: " + gs.score);
                Thread.sleep(delay);
            }
            //System.out.println("BRUH");
           // i--;
        //}
    }
    

    public static void runDark (AgentInterface agentController, GhostTeamController ghostTeam) throws Exception {
        Maze maze = new Maze();
        maze.processOldMaze(MazeOne.getMaze());
        GameState gs = new GameState(maze);
        gs.reset();
        // gs.nLivesRemaining = 10;
        Game game = new Game(gs, null, agentController, ghostTeam);
        ElapsedTimer t = new ElapsedTimer();
        int nRuns = 100;
        StatSummary ss = new StatSummary();
        PlaySound.disable();
        for (int i=0; i<nRuns; i++) {
            game.gs.reset();
            // gs.nLivesRemaining = 10;
            gs.nextLevel();
            game.run();
            ss.add(game.gs.score);
            System.out.println("Final score: " + game.gs.score + ", ticks = " + game.gs.gameTick);
        }
        System.out.println(t);
        System.out.println(ss);
    }

    public Game(GameState gs, GameStateView gsv, AgentInterface agentController, GhostTeamController ghostTeam) {
        this.gs = gs;
        this.gsv = gsv;
        this.agentController = agentController;
        this.ghostTeam = ghostTeam;
    }

    GameState gs;
    GameStateView gsv;
    AgentInterface agentController;
    GhostTeamController ghostTeam;
    JEasyFrame frame;

}
