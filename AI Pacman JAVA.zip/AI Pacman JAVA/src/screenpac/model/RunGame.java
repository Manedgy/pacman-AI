package screenpac.model;

public class RunGame {
    public static void main(String[] args) {
        // Map maze = Map.levelOne();
        // GameState gs = new
        
    }
}
