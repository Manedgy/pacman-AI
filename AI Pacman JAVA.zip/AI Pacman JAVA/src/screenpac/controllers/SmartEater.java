package screenpac.controllers;

import screenpac.model.Node;
import wox.serial.Util;
import screenpac.model.Game;
import screenpac.model.GameStateInterface;
import screenpac.model.GhostState;
import screenpac.features.EaterLogic;
import screenpac.features.NearestPillDistance;
import screenpac.features.Utilities;

import java.awt.Color;
import java.util.ArrayList;

import javax.sql.RowSetReader;

import screenpac.extract.Constants;

/**
 * This class is responsible for controlling the Pacman.
 * @author David Teixeira Nº67994
 * @author Pedro Santos Nº67984
 */
public class SmartEater implements AgentInterface, Constants {
    

    EaterLogic logic, logicEdible;

    /**
     * Constructor for SmartEater.
     */
    public SmartEater() {
        logic = new EaterLogic(); 
        logicEdible = new EaterLogic();
    }

    // private int getQuadrant(GameStateInterface gs, Node pac)
    // {
    //     //Node pac = gs.getPacman().current;
    //     int width = gs.getMaze().getWidth();
    //     int height = gs.getMaze().getHeight();

    //     if(pac.x <= width/2 && pac.y <= height/2) return 1; //1
    //     else if(pac.x <= width/2 && pac.y > height/2) return -2; //3
    //     else if(pac.x > width/2 && pac.y <= height/2) return 2; //2
    //     else return -1; //4
    // }

    /**
     * Reverses the provided direction
     * @param dir Direction to move.
     * @return Reversed direction.
     */
    private int invertDir(int dir)
    {
        int result = -1;
        if(dir == UP) result = DOWN;
        else if(dir == DOWN) result = UP;
        else if(dir == LEFT) result = RIGHT;
        else result = LEFT;
        return result;
    }

    /**
     * Make the Pacman move taking into account the ghosts' directions.
     * It selects a random possible path, where "possible" means that the path is not blocked by a ghost.
     * @param gs GameState
     * @param ghost A ghost
     * @param dir Direction to move
     * @param nearestPill The nearest pill to Pacman
     * @return The direction to move
     */
    private int dirGhost(GameStateInterface gs, GhostState ghost, int dir, Node nearestPill)
    {

        Node g = ghost.current, pac = gs.getPacman().current;

        Node next = Utilities.getClosest(pac.adj, g, gs.getMaze());
        int directionGhostPac = Utilities.getWrappedDirection(pac, next, gs.getMaze());

        //Num Canto
        //int[] allDirections = {UP, RIGHT, DOWN, LEFT};
        String[] allDirections = {"UP", "RIGHT", "DOWN", "LEFT"};
        // int UP = 0;
        // int RIGHT = 1;
        // int DOWN = 2;
        // int LEFT = 3;

        // System.out.println("ADJACENTS " + pac);
        // for(Node k : pac.adj)
        // {
        //     System.out.println("ADJ: " + k);
        // }
        // System.out.println("END ADJACENTS " + pac);

        ArrayList<Node> adj = pac.adj;
        int n = adj.size();
        //System.out.println(n);
        ArrayList<Integer> pacDirections = new ArrayList<>();

        for(int i = 0; i < n; i++)
            pacDirections.add(Utilities.getDirection(pac, pac.adj.get(i)));

        // System.out.println("START // BEFORE + PAC: " + pac);
        // for(int k : pacDirections)
        // {
        //     System.out.println("DIR: " + allDirections[k] + " NUM: " + k);
        // }
        // System.out.println("END");

        
        ArrayList<Integer> uniquePacDirections = new ArrayList<>();
        for(int i = 0; i < pacDirections.size(); i++)
        {
            if(!uniquePacDirections.contains(pacDirections.get(i))) uniquePacDirections.add(pacDirections.get(i));
            else uniquePacDirections.add(invertDir(pacDirections.get(i)));
        }

        for(int i = 0; i < uniquePacDirections.size(); i++)
            if(uniquePacDirections.get(i) == directionGhostPac) uniquePacDirections.remove(i);

        // System.out.println("START // AFTER + PAC: " + pac);
        // for(int k : uniquePacDirections)
        // {
        //     System.out.println("DIR: " + allDirections[k] + " NUM: " + k);
        // }
        // System.out.println("END");

        int end = uniquePacDirections.get(rand.nextInt(uniquePacDirections.size()));
        //System.out.println("RANDOM: " + allDirections[end]);
        // if(end == 3 && n == 2) end = 1;
        // else if(end == 1 && n == 2) end = 3;
        return end;
    }

    /**
     * Returns a random direction different from the provided one.
     * @param dir Direction to avoid.
     * @return The random direction to move.
     */
    private int randDir(int dir)
    {
        int random = dir;

        do {
            random = Constants.rand.nextInt(4);
        }
        while(random == dir); 

        return random;
    }

    /**
     * Get the index of the nearest ghost.
     * @param gs GameState
     * @param ghosts Array of all the ghosts
     * @return The index of the nearest ghost.
     */
    private int nearestGhostIndex(GameStateInterface gs, GhostState[] ghosts)
    {
        int[] distances = new int[ghosts.length];
        int min = Integer.MAX_VALUE;
        int j = 0;
        for(int i = 0; i < ghosts.length; i++)
        {
            distances[i] = Utilities.manhattan(ghosts[i].current, gs.getPacman().current);
            if(distances[i] < min) { min = distances[i]; j = i; }
        }
            
        return j;
    }

    /**
     * Represents the action that the Pacman should take.
     * @param gs Game State
     * @return The direction to where the Pacman should move taking into account the ghosts' moves and the nearest pill.
     */
    public int action(GameStateInterface gs) {

        gs = gs.copy();
        int result = 0;
        GhostState[] ghosts = gs.getGhosts();
        for(int i = 0; i < ghosts.length; i++)
        	if(ghosts[i].edible()) result++;
        
        Node current = gs.getPacman().current;
        logic.score(gs, current);
        logicEdible.scoreEdible(gs, current);
        
        Node next = null;

        // Array with manhanttan distances between ghosts and pacman
        int[] ghostDistances = new int[ghosts.length];
        for(int i = 0; i < ghosts.length; i++)
            ghostDistances[i] = Utilities.manhattan(gs.getPacman().current, ghosts[i].current);
        
        // if there are edible ghosts AND the distance between edible ghost and pill is <
        // if(result != 0 && Utilities.manhattan(current, npgE.closest) < Utilities.manhattan(current, npg.closest)) next = Utilities.getClosest(current.adj, npgE.closest, gs.getMaze());
        // else next = Utilities.getClosest(current.adj, npg.closest, gs.getMaze());

        //System.out.println(ghosts[0].edibleTime);
        //npg.closest.col = Color.YELLOW;
        ArrayList<Node> solutionPath = logic.aStar(gs);

        //int size = solutionPath.size();
        //next = size <= 1 ? solutionPath.get(0) : solutionPath.get(size-1);

        // System.out.println("START");
        // for(Node n : solutionPath)
        // {
        //     System.out.println(n);
        // }
        // System.out.println("ENDT");
        //System.out.println("NEXT: " + next + " PAC: " + gs.getPacman().current);
        //int changed = 0;
        Node sol = solutionPath.get(0);
        if(ghosts[0].edibleTime >= 30 && Utilities.manhattan(current, logicEdible.closest) < Utilities.manhattan(current, logic.closest)) next = Utilities.getClosest(current.adj, logicEdible.closest, gs.getMaze());
        else 
        {
            
        //     if(lastClosest != null && (lastClosest.x == sol.x && lastClosest.x == sol.y) || lastDistance >= bruh)  {
        //         sol = lastClosest;
        //         changed = 1;
        //  }
            next = Utilities.getClosest(current.adj, sol, gs.getMaze());
        }

        //System.out.println("BRUHHHH: " + gs.getMaze().dist(current, next));
        int dir = Utilities.getWrappedDirection(current, next, gs.getMaze());

        //System.out.println("DIR: " + dir);
        //System.out.println("LAST: " + lastClosest + " CURRENT: " + npg.closest);
        //if(changed == 0)  {

        // int sumAllGhostDistances = 0;
        // GhostState[] allGhosts = gs.getGhosts();
        // for(GhostState g : allGhosts)
        // {
        //     int distance = Utilities.manhattan(g.current, npg.closest);

        //     if(distance <= 10) sumAllGhostDistances += distance;
        // }

        // if(sumAllGhostDistances <= 5)
        // {
        //     int pacQuad = getQuadrant(gs, current);
        //     System.out.println("BRUH");
        //     for(Node n : gs.getMaze().getPills())
        //     {
        //         if(getQuadrant(gs, n) == pacQuad* (-1))
        //         {
        //             next = Utilities.getClosest(current.adj, n, gs.getMaze());
        //             dir = Utilities.getWrappedDirection(current, next, gs.getMaze());
        //             break;
        //         }
        //     }
        // }
        
        
        PathPlanner pp = new PathPlanner(gs.getMaze());
        ArrayList<Node> path = pp.getPath(current, logic.closest);
        //ArrayList<Node> path = solutionPath;
        for(int i = 0; i < path.size(); i++)
        {
            Node n = path.get(i);
            // for(int j = 0; j < ghosts.length; j++)
            //     {
            //         if(n.x == ghosts[j].current.x && n.y == ghosts[j].current.y) return 
            //     }
            n.col = Color.MAGENTA;

            GhostState nearestGhost = ghosts[nearestGhostIndex(gs, ghosts)];

            if(!nearestGhost.edible() && !nearestGhost.returning())
            {
                ArrayList<Node> allGhostsAdj = new ArrayList<>();
                for(Node a : nearestGhost.current.adj)
                {
                    allGhostsAdj.add(a);
                    for(Node b : a.adj)
                    {
                        allGhostsAdj.add(b);
                    }
                }

                for(Node a : allGhostsAdj)
                {
                    int gg = Utilities.manhattan(nearestGhost.current, gs.getPacman().current);
                    //int gg = Utilities.manhattan(nearestGhost.current, npg.closest);
                    //System.out.println("Nearest Ghost: " + gg);
                    //if((n.x == a.x && n.y == a.y) || (n.x == nearestGhost.current.x && n.y == nearestGhost.current.y) || gs.getMaze().dist(nearestGhost.current, gs.getPacman().current) <= 5)
                    if((n.x == a.x && n.y == a.y) || (n.x == nearestGhost.current.x && n.y == nearestGhost.current.y) || gg <= 10)
                    {
                        //int nextDir = randDir(dir);
                        int nextDir = dirGhost(gs, nearestGhost, dir, logic.closest);
                        return nextDir;
                    }
                }
            }

            //path.set(i, n);
        }
        //}
        //else lastClosest = sol;
        return dir;
    }

    // public ArrayList<Node> getSolutionPath(GameStateInterface gs) {

    //     Node current = gs.getPacman().current;
    //     logic.score(gs, current);

    //     ArrayList<Node> solutionPath = logic.aStar(gs);

    //     PathPlanner pp = new PathPlanner(gs.getMaze());
    //     //ArrayList<Node> path = pp.getPath(current, npg.closest);
    //     ArrayList<Node> path = solutionPath;
    //     for(int i = 0; i < path.size(); i++)
    //     {
    //         Node n = path.get(i);
    //         // for(int j = 0; j < ghosts.length; j++)
    //         //     {
    //         //         if(n.x == ghosts[j].current.x && n.y == ghosts[j].current.y) return 
    //         //     }
    //         n.col = Color.MAGENTA;
    //     }
    //     return solutionPath;
    // }
}